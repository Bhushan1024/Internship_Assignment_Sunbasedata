package com.sunbasedata.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sunbasedata.entity.AuthRequest;


@Service
public class AuthService {


    private String authApiUrl= "https://qa2.sunbasedata.com/sunbase/portal/api/assignment_auth.jsp";

    @Autowired
    RestTemplate restTemplate;

    

    public String authenticateUser(String loginId, String password) {
        
        AuthRequest authRequest = new AuthRequest();
        authRequest.setLogin_id(loginId);
        authRequest.setPassword(password);

        
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json");

        
        HttpEntity<AuthRequest> requestEntity = new HttpEntity<>(authRequest, headers);

        
        ResponseEntity<String> response = restTemplate.exchange(
                authApiUrl,
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        
        if (response.getStatusCode().is2xxSuccessful()) {
        	System.out.println(response.getBody());
            return response.getBody();
        } else {
        	System.out.println("Not Found");
            throw new RuntimeException("Authentication failed");
        }
    }
}

package com.sunbasedata.entity;

import lombok.Data;

@Data
public class Customer {
    private String first_name;
    private String last_name;
    private String street;
    private String address;
    private String city;
    private String state;
    private String email;
    private String phone;
    
    public Customer(){
    	
    }

	@Override
	public String toString() {
		return "Customer [first_name=" + first_name + ", last_name=" + last_name + ", street=" + street + ", address="
				+ address + ", city=" + city + ", state=" + state + ", email=" + email + ", phone=" + phone + "]";
	}
    
    
}

package com.sunbasedata.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunbasedata.entity.AuthRequest;
import com.sunbasedata.entity.Customer;

@Controller
public class UserConroller {
	  @GetMapping("/")
	    public String login(Model model) {

	    	model.addAttribute("authRequest",new AuthRequest());
	        return "login";
	    }
	  
	  
	  @GetMapping("/add")
	    public String create(Model model) {
	      
	    	model.addAttribute("customer",new Customer());
	        return "create";
	    }
	  
	  
	  @GetMapping("/update-form")
	    public String create(Model model,@RequestParam("uuid") String uuid) {
	       
	    	model.addAttribute("customer",new Customer());
	    	model.addAttribute("uuid",uuid);
	        return "update-form";
	    }
}

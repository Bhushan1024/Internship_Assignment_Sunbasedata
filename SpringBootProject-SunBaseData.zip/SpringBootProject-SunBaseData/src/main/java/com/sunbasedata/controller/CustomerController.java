package com.sunbasedata.controller;


import java.net.URI;
import java.net.URISyntaxException;

import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.sunbasedata.entity.Customer;

@RestController
@RequestMapping("/api")
public class CustomerController {

    @GetMapping("/getCustomerList")
    public ResponseEntity<String> getCustomerList(@RequestHeader("Authorization") String bearerToken) {
        System.out.println("BT : " + bearerToken);
    	HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer "+bearerToken);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.exchange(
            "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=get_customer_list",
            HttpMethod.GET,
            entity,
            String.class
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            return ResponseEntity.ok(response.getBody());
        } else {
            return ResponseEntity.status(response.getStatusCode()).body("Failed to fetch customer list");
        }
    }
    
    
    @PostMapping("/deleteCustomer")
    public ResponseEntity<String> deleteCustomer(
            @RequestParam String uuid,
            @RequestHeader("Authorization") String bearerToken
    ) {
      
        try {
            String apiUrl = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp";
            URI uri = new URI(apiUrl + "?cmd=delete&uuid=" + uuid);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", bearerToken);
            HttpEntity<String> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<String> response = new RestTemplate().exchange(
                uri,
                HttpMethod.POST,
                requestEntity,
                String.class
            );

            if (response.getStatusCode() == HttpStatus.OK) {
                return ResponseEntity.ok("Successfully deleted");
            } else if (response.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: Not deleted");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("UUID not found");
            }
        } catch (URISyntaxException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred");
        }
    }
    
    
    
    @PostMapping("/createCustomer")
    public String createCustomer(@ModelAttribute Customer customer, @RequestParam("Authorization") String Authorization) {
      
    	
    	System.out.println("Customer: " + customer);
        System.out.println("Authorization: " + Authorization);


       
        JSONObject requestBody = new JSONObject();
        
        requestBody.put("first_name", customer.getFirst_name());
        requestBody.put("last_name", customer.getLast_name());
        requestBody.put("street", customer.getStreet());
        requestBody.put("address", customer.getAddress());
        requestBody.put("city", customer.getCity());
        requestBody.put("state", customer.getState());
        requestBody.put("email", customer.getEmail());
        requestBody.put("phone", customer.getPhone());
        
        System.out.println("requestBody : " + requestBody);
        
       
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + Authorization);
        headers.setContentType(MediaType.APPLICATION_JSON);

        
        HttpEntity<String> request = new HttpEntity<>(requestBody.toString(), headers);

       
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.postForEntity(
                "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=create",
                request, String.class);

        if (response.getStatusCode() == HttpStatus.CREATED) {
           
            return "success"; 
        } else {
            
            return "error"; 
        }
    }
    
    
    
    @PostMapping("/updateCustomer")
    public ResponseEntity<String> updateCustomer(@ModelAttribute Customer customer,
    		@RequestParam("Authorization") String Authorization , @RequestParam("uuid") String uuid) {
    	
    	System.out.println("UC");
    	System.out.println("Customer : "+customer);
    	System.out.println("Authorization : "+Authorization);
    	System.out.println("uuid : "+uuid);
        
        String updateUrl = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=update&uuid=" + uuid;

        
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + Authorization);
        headers.setContentType(MediaType.APPLICATION_JSON);

       
        HttpEntity<Customer> request = new HttpEntity<>(customer, headers);

        
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.exchange(
            updateUrl,
            HttpMethod.POST, // Use POST or the appropriate method for your API
            request,
            String.class
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            return new ResponseEntity<>("Customer updated successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to update customer", HttpStatus.BAD_REQUEST);
        }
    }
    
   
}


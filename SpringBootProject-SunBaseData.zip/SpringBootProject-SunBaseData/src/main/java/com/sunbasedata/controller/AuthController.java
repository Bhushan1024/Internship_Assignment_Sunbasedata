package com.sunbasedata.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sunbasedata.entity.AuthRequest;
import com.sunbasedata.service.AuthService;

import jakarta.servlet.http.HttpSession;



@Controller
public class AuthController {

	@Autowired
    AuthService authService;

	


    @PostMapping("/authenticate")
    public String authenticateUser(@ModelAttribute AuthRequest authRequest,Model model,HttpSession session) {

    	String token=authService.authenticateUser(authRequest.getLogin_id(), authRequest.getPassword());;
    	System.out.println("Token : "+ token);
    	
    	String s = token.split(":")[1];
    	s = s.substring(1,s.length()-3);
    	System.out.println("Token : "+ s);
    	session.setAttribute("token", s);
    	
    	
        return "home";
    }
    
    
    
  
}

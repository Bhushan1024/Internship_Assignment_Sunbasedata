package com.sunbasedata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLoginLogoutSpringSecurityMySqlThymeleaf1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
